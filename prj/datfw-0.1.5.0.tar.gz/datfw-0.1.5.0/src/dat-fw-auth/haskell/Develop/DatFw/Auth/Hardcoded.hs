
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE QuasiQuotes #-}

module Develop.DatFw.Auth.Hardcoded
    ( module Develop.DatFw.Auth
    , hardcodedPlugin, WebAuthHardcoded(..)
    )
where
import Develop.DatFw hiding (dispatch)
import Develop.DatFw.Auth
import Develop.DatFw.Handler
import Develop.DatFw.Content
import Develop.DatFw.Widget
import Develop.DatFw.Template
import Develop.DatFw.Form
import Develop.DatFw.Form.Fields

import           Network.Wai
import           Network.HTTP.Types (Method)

import           Data.Text (Text)
import qualified Data.Text.Encoding as T
import           Data.ByteString.Builder
import           Text.Blaze.Html
import           Data.Int
import           Control.Monad            -- imports when, ...


-- ****************************************************************
-- Auth.Hardcoded: Plugin d'autenticacio.

-- Classe que defineix els aspectes de la configuracio del plugin 'hardcoded' del subsitema 'Auth' per als diferents llocs.
class WebAuth site => WebAuthHardcoded site where
    validatePassword :: (MonadHandler m, HandlerSite m ~ site) => Text -> Text ->  m Bool


hardcodedPlugin :: WebAuthHardcoded site => AuthPlugin site
hardcodedPlugin = AuthPlugin
        { pluginName = "hardcoded"
        , pluginLoginW = loginW
        , pluginDispatch = dispatch
        }
    where
        loginW toMaster = do
            (_, formw) <- runAFormPost loginForm
            loginView toMaster formw
        dispatch ["login"] "POST" = postLoginR
        dispatch ["login"] _      = badMethod
        dispatch _         _      = notFound


loginForm :: MonadHandler m => AForm m (Text, Text)
loginForm =
    (,) <$> freq textField "Nom d'usuari" Nothing
        <*> freq passwordField "Clau d'accés" Nothing

loginView :: (Route Auth -> Route site) -> Widget site -> Widget site
loginView toMaster formw = [widgetTempl|
<div class="row">
  <div class="col-sm-offset-2 col-sm-10">
    <form role="form" method="POST" action="@{toMaster (DialogR "hardcoded" ["login"])}">
      ^{formw}
      <div class="form-group"><button type="submit" class="btn btn-success">Entra</button></div>
    </form>
  </div>
</div>
|]

postLoginR :: WebAuthHardcoded site => SubHandlerFor Auth site TypedContent
postLoginR = do
    toMaster <- getRouteToMaster
    (formr, formw) <- runAFormPost loginForm
    case formr of
        FormSuccess (name, password) -> do
            ok <- validatePassword name password
            if ok then do
                let creds = Creds "hardcoded" name []
                setCredsRedirect creds
            else do
                toMaster <- getRouteToMaster
                toTypedContent <$> onErrorHtml (toMaster LoginR) "Error d'autenticaciò"
        _ ->
            toTypedContent <$> authLayout (loginView toMaster formw)

