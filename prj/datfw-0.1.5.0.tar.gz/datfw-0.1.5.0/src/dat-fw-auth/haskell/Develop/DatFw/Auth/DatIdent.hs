
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE QuasiQuotes #-}

module Develop.DatFw.Auth.DatIdent
    ( module Develop.DatFw.Auth
    , datIdentPlugin, datIdentPluginWithUrl, defaultDatIdentServerUrl
    , datIdentPluginName
    )
where
import Develop.DatFw hiding (dispatch)
import Develop.DatFw.Auth
import Develop.DatFw.Handler
import Develop.DatFw.Content
import Develop.DatFw.Widget
import Develop.DatFw.Template
import Develop.DatFw.Form
import Develop.DatFw.Form.Fields

import           Network.Wai
import           Network.HTTP.Types

import           Data.Monoid
import           Data.Text (Text)
import qualified Data.Text.Encoding as T
import           Data.ByteString.Builder
import qualified Data.ByteString.Lazy as BL
import           Text.Blaze.Html
import           Data.Int
import           Control.Monad            -- imports when, ...


-- ****************************************************************
{- Auth.DatIdent: Plugin d'autenticacio.

==  Protocol amb el servidor d'usuaris ==
En el client (http://soft0.upc.edu:8080/www-shell):
------------
1 - GET a URL que requereix autenticació
2 - Redirecció via form-redirect

En el servidor (http://soft0.upc.edu:8080/ident):
--------------
2 - POST http://soft0.upc.edu:8080/ident/sso/browser
        Content-Type: application/x-www-form-urlencoded
        Content: ident.mode             authn_req
                 ident.return_to        http://soft0.upc.edu:8080/www-shell/loginResp
3 - Ok 200
        Content-Type: text/html
        Content: Formulari login

4 - POST http://soft0.upc.edu:8080/ident/submitLogin.do
        Content-Type: application/x-www-form-urlencoded
        Content: login          Login
                 nonce          d92c700174f3335a-c7db4499ed5b3030
                 password       xxxxxxxxx
                 uname          webmaster
5 - Redirecció via form-redirect

En el client (http://soft0.upc.edu:8080/www-shell):
------------
5 - POST http://soft0.upc.edu:8080/www-shell/loginResp
        Content-Type: application/x-www-form-urlencoded
        Content: ident.identity         webmaster
                 ident.mode             id_res
                 ident.return_to        http://soft0.upc.edu:8080/www-shell/loginResp
                 ident.server           http://soft0.upc.edu:8080/ident/
6 - Redirecció 302
        Location: http://soft0.upc.edu:8080/www-shell/main

-}

datIdentPlugin :: WebAuth site => AuthPlugin site
datIdentPlugin = datIdentPluginWithUrl defaultDatIdentServerUrl
 
defaultDatIdentServerUrl :: Text
defaultDatIdentServerUrl = "http://soft0.upc.edu:8080/ident/sso/browser"

datIdentPluginName :: Text
datIdentPluginName = "datident"

datIdentPluginWithUrl :: WebAuth site => Text -> AuthPlugin site
datIdentPluginWithUrl serverUrl = AuthPlugin
        { pluginName = datIdentPluginName
        , pluginLoginW = loginW
        , pluginDispatch = dispatch serverUrl
        }

-- ****************************************************************
-- Handlers del subsitema Auth.Password.

loginW :: (Route Auth -> Route site) -> Widget site
loginW toMaster = [widgetTempl|
<div class="row">
  <div class="col-sm-offset-2 col-sm-10">
    <form role="form" method="POST" action="@{toMaster (DialogR datIdentPluginName ["forward"])}">
    <button id="forward-button" type="submit" class="btn btn-success">Autenticació amb el servidor d'usuaris de DAT</button>
    </form>
  </div>
</div>
|]

dispatch :: WebAuth site => Text -> [Text] -> Method -> SubHandlerFor Auth site TypedContent
dispatch serverUrl ["forward"] "POST" = postForwardR serverUrl
dispatch serverUrl ["return"]  "POST" = postReturnR
dispatch _         _           _      = notFound

returnRoute :: Route Auth
returnRoute = DialogR datIdentPluginName ["return"]

postForwardR :: Text -> SubHandlerFor Auth site a
postForwardR serverUrl = do
    tm <- getRouteToMaster
    returnUrl <- getUrlRender >>= \ render -> pure $ render (tm returnRoute) []
    let params = [("ident.mode", "authn_req"), ("ident.return_to", returnUrl)]
        qtext = renderQueryText True (fmap Just <$> params)
        toUrl = serverUrl <> T.decodeUtf8 (BL.toStrict $ toLazyByteString qtext)
    redirect toUrl

postReturnR :: WebAuth site => SubHandlerFor Auth site TypedContent
postReturnR = do
    mode <- lookupPostParam "ident.mode" >>= maybe (invalidArgs ["ident.mode"]) pure
    when (mode /= "id_res") $
        invalidArgs ["ident.mode"]
    server <- lookupPostParam "ident.server" >>= maybe (invalidArgs ["ident.server"]) pure
    identity <- lookupPostParam "ident.identity" >>= maybe (invalidArgs ["ident.identity"]) pure
    return_to <- lookupPostParam "ident.return_to" >>= maybe (invalidArgs ["ident.return_to"]) pure
    tm <- getRouteToMaster
    selfUrl <- getUrlRender >>= \ render -> pure $ render (tm returnRoute) []
    when (return_to /= selfUrl) $
        invalidArgs ["ident.return_to"]

    let creds = Creds datIdentPluginName (server <> identity) [("name", identity)]
    setCredsRedirect creds

