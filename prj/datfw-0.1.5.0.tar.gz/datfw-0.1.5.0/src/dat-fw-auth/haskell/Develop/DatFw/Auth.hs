
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE QuasiQuotes #-}

module Develop.DatFw.Auth
    ( Auth, getAuth
    , Route(..)
    , WebAuth(..), AuthenticationResult(..), WebAuthPersist(..)
    , maybeAuthId, requireAuthId, maybeAuth, requireAuth
    , AuthPlugin(..), Creds(..)
    , authId_SESSION_KEY, setCredsRedirect
    )
where
import Develop.DatFw
import Develop.DatFw.Dispatch
import Develop.DatFw.Handler
import Develop.DatFw.Widget
import Develop.DatFw.Template
import Develop.DatFw.Content

import           Network.Wai (requestMethod)
import           Network.HTTP.Types (Method)

import           Data.Text (Text)
import qualified Data.Text.Encoding as T
import           Data.ByteString.Builder
import           Text.Blaze.Html
import           Data.List
import           Control.Monad            -- imports when, ...
import           Control.Monad.Trans.Maybe


-- ****************************************************************
-- Auth: Subsistema d'autenticacio.

-- Definicio del tipus Auth (estat del subsistema) i de la funcio que obte el corresponent valor a partir d'un site.
--      En aquest cas, no hi ha informacio global de subsistema i la funcio getAuth sempre obte un valor constant.
data Auth = Auth

getAuth :: site -> Auth
getAuth _ = Auth

-- Rutes del subsitema Auth.
instance RenderRoute Auth where
    data Route Auth =
        LoginR | LogoutR | DialogR Text [Text]

    renderRoute LoginR  = (["login"], [])
    renderRoute LogoutR = (["logout"], [])
    renderRoute (DialogR name path) = ("dialog":name:path, [])


-- Classe que defineix els aspectes de la configuracio del subsitema Auth per als diferents llocs.
class (WebApp site, PathPiece (AuthId site)) => WebAuth site where
    type AuthId site

    authLayout :: (MonadHandler m, site ~ HandlerSite m) => Widget site -> m Html
    authLayout widget =
        liftHandler $ defaultLayout widget

    -- | Perform authentication based on the given credentials.
    authenticate :: (MonadHandler m, HandlerSite m ~ site) => Creds site -> m (AuthenticationResult site)

    -- | After login and logout (from the browser), redirect to the referring page, instead of
    -- 'loginDest' and 'logoutDest'. Default is 'False'.
    redirectToReferer :: site -> Bool
    redirectToReferer _ = False

    -- | When being redirected to the login page should the current page
    -- be set to redirect back to. Default is 'True'.
    redirectToCurrent :: site -> Bool
    redirectToCurrent _ = True

    -- | Default destination on successful login, if no other destination exists.
    loginDest  :: site -> Route site

    -- | Default destination on successful logout, if no other destination exists.
    logoutDest :: site -> Route site

    -- | Called on login error for HTTP requests. By default, calls
    -- @addMessage@ with "error" as status and redirects to @dest@.
    onErrorHtml :: (MonadHandler m, HandlerSite m ~ site) => Route site -> Text -> m Html
    onErrorHtml dest msg = do
        ---addMessage "error" $ toMarkup msg
        setMessage $ toMarkup msg
        redirect dest

    authPlugins :: site -> [AuthPlugin site]

-- | The result of an authentication based on credentials
data AuthenticationResult site
    = Authenticated (AuthId site) -- ^ Authenticated successfully
    | UserError Text              -- ^ Invalid credentials provided by user
        -- TODO: Define a more explicit type (p.ex: AuthMessage)for the user error
    | ServerError Text            -- ^ Some other error


-- Classe que defineix els aspectes de la configuracio del subsitema Auth per als diferents llocs.
class WebAuth site => WebAuthPersist site where
    type AuthEntity site
    getAuthEntity :: (MonadHandler m, site ~ HandlerSite m) => AuthId site -> m (Maybe (AuthEntity site))


-- Utilitats a ser usades pels llocs

authId_SESSION_KEY :: Text
authId_SESSION_KEY = "__AUTHID"

maybeAuthId :: (MonadHandler m, site ~ HandlerSite m, WebAuth site) => m (Maybe (AuthId site))
maybeAuthId = runMaybeT $ do
    sid <- MaybeT $ lookupSession authId_SESSION_KEY
    MaybeT $ return $ fromPathPiece sid

requireAuthId :: (MonadHandler m, site ~ HandlerSite m, WebAuth site) => m (AuthId site)
requireAuthId = do
    mbaid <- maybeAuthId
    maybe handleNoAuthId pure mbaid

handleNoAuthId :: (WebAuth (HandlerSite m), MonadHandler m) => m a
handleNoAuthId = do
    let aj = False -- acceptsJson (TODO)
    if aj then notAuthenticated else do
        site <- getSite
        when (redirectToCurrent site) setUltDestCurrent
        case authRoute site of
            Just z -> redirect z
            Nothing -> permissionDenied "Please configure authRoute"


maybeAuth :: (MonadHandler m, site ~ HandlerSite m, WebAuthPersist site) => m (Maybe (AuthId site, AuthEntity site))
maybeAuth = runMaybeT $ do
    aid <- MaybeT maybeAuthId
    ae <- MaybeT $ getAuthEntity aid
    pure (aid, ae)

requireAuth :: (MonadHandler m, site ~ HandlerSite m, WebAuthPersist site) => m (AuthId site, AuthEntity site)
requireAuth = do
    mbp <- maybeAuth
    maybe handleNoAuthId pure mbp


-- ****************************************************************
-- Plugins.

data AuthPlugin site = AuthPlugin
        { pluginName :: Text
        , pluginLoginW :: (Route Auth -> Route site) -> Widget site
        , pluginDispatch :: [Text] -> Method -> SubHandlerFor Auth site TypedContent
        }

-- | User credentials
data Creds site = Creds
    { credsPlugin :: Text -- ^ How the user was authenticated
    , credsIdent :: Text  -- ^ Identifier. Exact meaning depends on plugin.
    , credsExtra :: [(Text, Text)]
    } deriving (Show)

-- ****************************************************************
-- Dispatch de les rutes del subsitema Auth.

instance WebAuth site => SubDispatch Auth site where
    subDispatch = subrouting
            $ route ( onStatic ["login"] ) LoginR
                [ onMethod "GET" getLoginR
                ]
            <||> route ( onStatic ["logout"] ) LogoutR
                (onAnyMethod handleLogoutR)
            <||> route ( onStatic ["dialog"] <&&> onDynamic <&&> onDynamicMulti ) DialogR
                (onAnyMethod2 handleDialogR)

-- ****************************************************************
-- Handlers del subsitema Auth.

getLoginR :: WebAuth site => SubHandlerFor Auth site Html
getLoginR = do
    setUltDestReferer'
    -- Return HTML page
    plugins <- getsSite authPlugins
    toMaster <- getRouteToMaster
    authLayout [widgetTempl|
$forall{ pg <- plugins }
  <hr>
  <div class="row">
    ^{pluginLoginW pg toMaster}
  </div>
$end
<hr>
|]

handleLogoutR :: WebAuth site => SubHandlerFor Auth site ()
handleLogoutR = do
    site <- getSite
    setUltDestReferer'
    deleteSession authId_SESSION_KEY
    redirectUltDest $ logoutDest site

setUltDestReferer' :: WebAuth site => SubHandlerFor Auth site ()
setUltDestReferer' = do
    site <- getSite
    when (redirectToReferer site) setUltDestReferer

handleDialogR :: WebAuth site => Text -> [Text] -> SubHandlerFor Auth site TypedContent
handleDialogR pgName pgPath = do
    plugins <- getsSite authPlugins
    case find ((pgName ==) . pluginName) plugins of
        Nothing -> notFound
        Just plugin -> do
            req <- getRequest
            pluginDispatch plugin pgPath (requestMethod req)


-- ****************************************************************
-- AuthId management.

setCredsRedirect :: (MonadHandler m, WebAuth (HandlerSite m))
                 => Creds (HandlerSite m) -- ^ new credentials
                 -> m TypedContent
setCredsRedirect creds = do
    site <- getSite
    authr <- authenticate creds
    case authr of
        Authenticated aid -> do
            setSession authId_SESSION_KEY $ toPathPiece aid
            redirectUltDest $ loginDest site
        UserError msg ->
            case authRoute site of
                Nothing -> do
                    toTypedContent <$> authLayout [widgetTempl|<h1>#{msg}</h1>|]
                Just ar -> toTypedContent <$> onErrorHtml ar msg
        ServerError msg ->
            case authRoute site of
                Nothing -> do
                    toTypedContent <$> authLayout [widgetTempl|<h1>Error d'autenticació: #{msg}</h1>|]
                Just ar -> toTypedContent <$> onErrorHtml ar msg

